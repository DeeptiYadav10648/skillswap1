import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { Plus, Search, Filter, Star, MapPin, Clock } from 'lucide-react';

interface Skill {
  id: string;
  name: string;
  category: string;
  description: string | null;
}

interface UserSkill {
  id: string;
  skill_id: string;
  skill_type: 'offer' | 'want';
  experience_level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  description: string | null;
  skills: Skill;
}

interface Profile {
  id: string;
  username: string;
  full_name: string;
  avatar_url: string | null;
  bio: string | null;
  location: string | null;
  rating: number;
  total_reviews: number;
}

interface UserWithSkills extends Profile {
  user_skills: UserSkill[];
}

export function DashboardPage() {
  const { user } = useAuth();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [userSkills, setUserSkills] = useState<UserSkill[]>([]);
  const [potentialMatches, setPotentialMatches] = useState<UserWithSkills[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddSkill, setShowAddSkill] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      // Load all skills
      const { data: skillsData } = await supabase
        .from('skills')
        .select('*')
        .order('name');

      // Load user's skills
      const { data: userSkillsData } = await supabase
        .from('user_skills')
        .select(`
          *,
          skills (*)
        `)
        .eq('user_id', user?.id);

      // Load potential matches
      const { data: matchesData } = await supabase
        .from('profiles')
        .select(`
          *,
          user_skills (
            *,
            skills (*)
          )
        `)
        .neq('id', user?.id);

      setSkills(skillsData || []);
      setUserSkills(userSkillsData || []);
      setPotentialMatches(matchesData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const categories = [...new Set(skills.map(skill => skill.category))];

  const filteredSkills = skills.filter(skill => 
    skill.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (selectedCategory === '' || skill.category === selectedCategory)
  );

  const getMatchScore = (otherUser: UserWithSkills) => {
    const myOffers = userSkills.filter(s => s.skill_type === 'offer').map(s => s.skill_id);
    const myWants = userSkills.filter(s => s.skill_type === 'want').map(s => s.skill_id);
    const theirOffers = otherUser.user_skills.filter(s => s.skill_type === 'offer').map(s => s.skill_id);
    const theirWants = otherUser.user_skills.filter(s => s.skill_type === 'want').map(s => s.skill_id);

    const iCanHelpThem = myOffers.filter(skill => theirWants.includes(skill)).length;
    const theyCanHelpMe = theirOffers.filter(skill => myWants.includes(skill)).length;

    return iCanHelpThem + theyCanHelpMe;
  };

  const topMatches = potentialMatches
    .map(user => ({ ...user, matchScore: getMatchScore(user) }))
    .filter(user => user.matchScore > 0)
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, 6);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Dashboard</h1>
          <p className="text-gray-600">Manage your skills and discover potential matches</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center">
                <Plus className="w-6 h-6 text-cyan-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Skills Offered</p>
                <p className="text-2xl font-bold text-gray-900">
                  {userSkills.filter(s => s.skill_type === 'offer').length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Search className="w-6 h-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Skills Wanted</p>
                <p className="text-2xl font-bold text-gray-900">
                  {userSkills.filter(s => s.skill_type === 'want').length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center">
                <Star className="w-6 h-6 text-teal-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Potential Matches</p>
                <p className="text-2xl font-bold text-gray-900">{topMatches.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-indigo-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Exchanges</p>
                <p className="text-2xl font-bold text-gray-900">0</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* My Skills */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">My Skills</h2>
                <button
                  onClick={() => setShowAddSkill(true)}
                  className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium rounded-lg hover:from-cyan-600 hover:to-blue-700 transition-all"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Skill
                </button>
              </div>

              {userSkills.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Plus className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No skills added yet</h3>
                  <p className="text-gray-600 mb-4">Start by adding skills you can offer or want to learn.</p>
                  <button
                    onClick={() => setShowAddSkill(true)}
                    className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium rounded-lg hover:from-cyan-600 hover:to-blue-700 transition-all"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Skill
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-3">Skills I Offer</h3>
                    <div className="grid gap-3">
                      {userSkills.filter(s => s.skill_type === 'offer').map((userSkill) => (
                        <div key={userSkill.id} className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                          <div>
                            <h4 className="font-medium text-gray-900">{userSkill.skills.name}</h4>
                            <p className="text-sm text-gray-600">
                              {userSkill.experience_level} • {userSkill.skills.category}
                            </p>
                            {userSkill.description && (
                              <p className="text-sm text-gray-500 mt-1">{userSkill.description}</p>
                            )}
                          </div>
                          <span className="px-3 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                            Offering
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-3">Skills I Want to Learn</h3>
                    <div className="grid gap-3">
                      {userSkills.filter(s => s.skill_type === 'want').map((userSkill) => (
                        <div key={userSkill.id} className="flex items-center justify-between p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <div>
                            <h4 className="font-medium text-gray-900">{userSkill.skills.name}</h4>
                            <p className="text-sm text-gray-600">
                              {userSkill.experience_level} • {userSkill.skills.category}
                            </p>
                            {userSkill.description && (
                              <p className="text-sm text-gray-500 mt-1">{userSkill.description}</p>
                            )}
                          </div>
                          <span className="px-3 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">
                            Learning
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Top Matches */}
          <div>
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Top Matches</h2>
              
              {topMatches.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Search className="w-6 h-6 text-gray-400" />
                  </div>
                  <p className="text-gray-600 text-sm">Add skills to see potential matches</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {topMatches.map((match) => (
                    <div key={match.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-medium text-gray-900">{match.full_name}</h3>
                          <p className="text-sm text-gray-600">@{match.username}</p>
                          {match.location && (
                            <div className="flex items-center mt-1">
                              <MapPin className="w-3 h-3 text-gray-400 mr-1" />
                              <span className="text-xs text-gray-500">{match.location}</span>
                            </div>
                          )}
                        </div>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-400 mr-1" />
                          <span className="text-sm text-gray-600">{match.rating.toFixed(1)}</span>
                        </div>
                      </div>
                      
                      <div className="text-xs text-gray-500 mb-2">
                        {match.matchScore} skill{match.matchScore !== 1 ? 's' : ''} in common
                      </div>
                      
                      <div className="flex flex-wrap gap-1">
                        {match.user_skills.slice(0, 3).map((skill) => (
                          <span
                            key={skill.id}
                            className={`px-2 py-1 text-xs font-medium rounded-full ${
                              skill.skill_type === 'offer'
                                ? 'bg-green-100 text-green-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {skill.skills.name}
                          </span>
                        ))}
                        {match.user_skills.length > 3 && (
                          <span className="px-2 py-1 text-xs text-gray-500 bg-gray-100 rounded-full">
                            +{match.user_skills.length - 3} more
                          </span>
                        )}
                      </div>
                      
                      <button className="w-full mt-3 px-3 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium rounded-lg hover:from-cyan-600 hover:to-blue-700 transition-all">
                        Connect
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Add Skill Modal */}
        {showAddSkill && (
          <AddSkillModal
            skills={filteredSkills}
            categories={categories}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            onClose={() => setShowAddSkill(false)}
            onSkillAdded={loadData}
          />
        )}
      </div>
    </div>
  );
}

// Add Skill Modal Component
interface AddSkillModalProps {
  skills: Skill[];
  categories: string[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  onClose: () => void;
  onSkillAdded: () => void;
}

function AddSkillModal({ 
  skills, 
  categories, 
  searchTerm, 
  setSearchTerm, 
  selectedCategory, 
  setSelectedCategory, 
  onClose, 
  onSkillAdded 
}: AddSkillModalProps) {
  const { user } = useAuth();
  const [selectedSkill, setSelectedSkill] = useState<Skill | null>(null);
  const [skillType, setSkillType] = useState<'offer' | 'want'>('offer');
  const [experienceLevel, setExperienceLevel] = useState<'beginner' | 'intermediate' | 'advanced' | 'expert'>('beginner');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSkill || !user) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('user_skills')
        .insert({
          user_id: user.id,
          skill_id: selectedSkill.id,
          skill_type: skillType,
          experience_level: experienceLevel,
          description: description || null,
        });

      if (error) throw error;

      onSkillAdded();
      onClose();
    } catch (error) {
      console.error('Error adding skill:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Add a Skill</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              ×
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Search and Filter */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search Skills
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="Search for skills..."
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Filter by Category
                </label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                >
                  <option value="">All Categories</option>
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              {/* Skills List */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select a Skill
                </label>
                <div className="max-h-40 overflow-y-auto border border-gray-300 rounded-lg">
                  {skills.map((skill) => (
                    <button
                      key={skill.id}
                      type="button"
                      onClick={() => setSelectedSkill(skill)}
                      className={`w-full text-left p-3 hover:bg-gray-50 border-b border-gray-100 last:border-b-0 ${
                        selectedSkill?.id === skill.id ? 'bg-cyan-50 border-cyan-200' : ''
                      }`}
                    >
                      <div className="font-medium text-gray-900">{skill.name}</div>
                      <div className="text-sm text-gray-600">{skill.category}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {selectedSkill && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    I want to...
                  </label>
                  <div className="flex space-x-4">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        value="offer"
                        checked={skillType === 'offer'}
                        onChange={(e) => setSkillType(e.target.value as 'offer')}
                        className="text-cyan-600 focus:ring-cyan-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">Offer this skill</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        value="want"
                        checked={skillType === 'want'}
                        onChange={(e) => setSkillType(e.target.value as 'want')}
                        className="text-cyan-600 focus:ring-cyan-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">Learn this skill</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Experience Level
                  </label>
                  <select
                    value={experienceLevel}
                    onChange={(e) => setExperienceLevel(e.target.value as any)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                  >
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                    <option value="expert">Expert</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (Optional)
                  </label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="Tell others about your experience or what you're looking for..."
                  />
                </div>
              </>
            )}

            <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!selectedSkill || loading}
                className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {loading ? 'Adding...' : 'Add Skill'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}