import React from 'react';
import { MessageCircle, Users, Clock } from 'lucide-react';

export function ChatPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Messages</h1>
          <p className="text-gray-600">Chat with your skill exchange partners</p>
        </div>

        {/* Chat Interface - Coming Soon */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="flex h-[600px]">
            {/* Sidebar */}
            <div className="w-1/3 bg-gray-50 border-r border-gray-200 p-4">
              <div className="mb-4">
                <h2 className="text-lg font-semibold text-gray-900 mb-2">Conversations</h2>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search conversations..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 text-sm"
                  />
                </div>
              </div>

              {/* Conversation List - Empty State */}
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No conversations yet</h3>
                <p className="text-gray-600 text-sm">
                  Start chatting when you have accepted skill matches.
                </p>
              </div>
            </div>

            {/* Main Chat Area */}
            <div className="flex-1 flex flex-col">
              {/* Chat Header */}
              <div className="p-4 border-b border-gray-200 bg-white">
                <div className="text-center">
                  <h3 className="text-lg font-medium text-gray-900">Select a conversation</h3>
                  <p className="text-sm text-gray-600">Choose a conversation from the sidebar to start chatting</p>
                </div>
              </div>

              {/* Chat Messages Area */}
              <div className="flex-1 p-6 flex items-center justify-center">
                <div className="text-center max-w-md">
                  <div className="w-20 h-20 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Users className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Real-time Chat Coming Soon!</h2>
                  <p className="text-gray-600 leading-relaxed mb-6">
                    We're building a comprehensive chat system that will allow you to communicate 
                    directly with your skill exchange partners. Features will include:
                  </p>
                  <div className="space-y-3 text-left">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
                      <span className="text-gray-700">Real-time messaging</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
                      <span className="text-gray-700">File and media sharing</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
                      <span className="text-gray-700">Video call integration</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
                      <span className="text-gray-700">Session scheduling</span>
                    </div>
                  </div>
                  <div className="mt-8 p-4 bg-cyan-50 rounded-lg">
                    <div className="flex items-center justify-center space-x-2 text-cyan-600">
                      <Clock className="w-5 h-5" />
                      <span className="font-medium">Expected launch: Next update</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}