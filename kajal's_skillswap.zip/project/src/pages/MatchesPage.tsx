import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { Star, MapPin, MessageCircle, Clock, CheckCircle, X } from 'lucide-react';

interface Match {
  id: string;
  requester_id: string;
  provider_id: string;
  requested_skill_id: string;
  offered_skill_id: string;
  status: 'pending' | 'accepted' | 'declined' | 'completed';
  created_at: string;
  updated_at: string;
  requester_profile: {
    id: string;
    username: string;
    full_name: string;
    avatar_url: string | null;
    bio: string | null;
    location: string | null;
    rating: number;
    total_reviews: number;
  };
  provider_profile: {
    id: string;
    username: string;
    full_name: string;
    avatar_url: string | null;
    bio: string | null;
    location: string | null;
    rating: number;
    total_reviews: number;
  };
  requested_skill: {
    id: string;
    name: string;
    category: string;
  };
  offered_skill: {
    id: string;
    name: string;
    category: string;
  };
}

export function MatchesPage() {
  const { user } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'accepted' | 'completed'>('all');

  useEffect(() => {
    if (user) {
      loadMatches();
    }
  }, [user]);

  const loadMatches = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('skill_matches')
        .select(`
          *,
          requester_profile: profiles!skill_matches_requester_id_fkey (*),
          provider_profile: profiles!skill_matches_provider_id_fkey (*),
          requested_skill: skills!skill_matches_requested_skill_id_fkey (*),
          offered_skill: skills!skill_matches_offered_skill_id_fkey (*)
        `)
        .or(`requester_id.eq.${user.id},provider_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMatches(data || []);
    } catch (error) {
      console.error('Error loading matches:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateMatchStatus = async (matchId: string, status: 'accepted' | 'declined') => {
    try {
      const { error } = await supabase
        .from('skill_matches')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', matchId);

      if (error) throw error;
      await loadMatches();
    } catch (error) {
      console.error('Error updating match status:', error);
    }
  };

  const filteredMatches = matches.filter(match => {
    if (activeTab === 'all') return true;
    return match.status === activeTab;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'declined':
        return 'bg-red-100 text-red-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'accepted':
        return <MessageCircle className="w-4 h-4" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading matches...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Matches</h1>
          <p className="text-gray-600">Manage your skill exchange connections</p>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { key: 'all', label: 'All Matches', count: matches.length },
                { key: 'pending', label: 'Pending', count: matches.filter(m => m.status === 'pending').length },
                { key: 'accepted', label: 'Active', count: matches.filter(m => m.status === 'accepted').length },
                { key: 'completed', label: 'Completed', count: matches.filter(m => m.status === 'completed').length },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.key
                      ? 'border-cyan-500 text-cyan-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    activeTab === tab.key
                      ? 'bg-cyan-100 text-cyan-600'
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    {tab.count}
                  </span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Matches List */}
        {filteredMatches.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {activeTab === 'all' ? 'No matches yet' : `No ${activeTab} matches`}
            </h3>
            <p className="text-gray-600 mb-6">
              {activeTab === 'all' 
                ? 'Start adding skills to your profile to find potential matches.'
                : `You don't have any ${activeTab} matches at the moment.`
              }
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredMatches.map((match) => {
              const isRequester = match.requester_id === user?.id;
              const otherUser = isRequester ? match.provider_profile : match.requester_profile;
              const mySkill = isRequester ? match.requested_skill : match.offered_skill;
              const theirSkill = isRequester ? match.offered_skill : match.requested_skill;

              return (
                <div key={match.id} className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                        {otherUser.full_name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{otherUser.full_name}</h3>
                        <p className="text-sm text-gray-600">@{otherUser.username}</p>
                        {otherUser.location && (
                          <div className="flex items-center mt-1">
                            <MapPin className="w-3 h-3 text-gray-400 mr-1" />
                            <span className="text-xs text-gray-500">{otherUser.location}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-400 mr-1" />
                        <span className="text-sm text-gray-600">{otherUser.rating.toFixed(1)}</span>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getStatusColor(match.status)}`}>
                        {getStatusIcon(match.status)}
                        <span className="capitalize">{match.status}</span>
                      </span>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="text-xs font-medium text-blue-600 uppercase tracking-wide mb-1">
                        {isRequester ? 'You want to learn' : 'They want to learn'}
                      </div>
                      <div className="font-medium text-gray-900">{mySkill.name}</div>
                      <div className="text-sm text-gray-600">{mySkill.category}</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-xs font-medium text-green-600 uppercase tracking-wide mb-1">
                        {isRequester ? 'They can teach' : 'You can teach'}
                      </div>
                      <div className="font-medium text-gray-900">{theirSkill.name}</div>
                      <div className="text-sm text-gray-600">{theirSkill.category}</div>
                    </div>
                  </div>

                  {otherUser.bio && (
                    <div className="mb-4">
                      <p className="text-sm text-gray-600 line-clamp-2">{otherUser.bio}</p>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <div className="text-xs text-gray-500">
                      {isRequester ? 'Your request' : 'Request from ' + otherUser.full_name} • {new Date(match.created_at).toLocaleDateString()}
                    </div>
                    <div className="flex space-x-2">
                      {match.status === 'pending' && !isRequester && (
                        <>
                          <button
                            onClick={() => updateMatchStatus(match.id, 'declined')}
                            className="px-3 py-1 text-red-600 bg-red-50 rounded-md text-sm font-medium hover:bg-red-100 transition-colors flex items-center space-x-1"
                          >
                            <X className="w-3 h-3" />
                            <span>Decline</span>
                          </button>
                          <button
                            onClick={() => updateMatchStatus(match.id, 'accepted')}
                            className="px-3 py-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-md text-sm font-medium hover:from-cyan-600 hover:to-blue-700 transition-all flex items-center space-x-1"
                          >
                            <CheckCircle className="w-3 h-3" />
                            <span>Accept</span>
                          </button>
                        </>
                      )}
                      {match.status === 'accepted' && (
                        <button className="px-3 py-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-md text-sm font-medium hover:from-cyan-600 hover:to-blue-700 transition-all flex items-center space-x-1">
                          <MessageCircle className="w-3 h-3" />
                          <span>Chat</span>
                        </button>
                      )}
                      {match.status === 'pending' && isRequester && (
                        <span className="px-3 py-1 bg-yellow-50 text-yellow-600 rounded-md text-sm font-medium">
                          Waiting for response
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}