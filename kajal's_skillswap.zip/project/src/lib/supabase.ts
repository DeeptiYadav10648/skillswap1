import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          username: string;
          full_name: string;
          avatar_url: string | null;
          bio: string | null;
          location: string | null;
          rating: number;
          total_reviews: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          username: string;
          full_name: string;
          avatar_url?: string | null;
          bio?: string | null;
          location?: string | null;
          rating?: number;
          total_reviews?: number;
        };
        Update: {
          username?: string;
          full_name?: string;
          avatar_url?: string | null;
          bio?: string | null;
          location?: string | null;
          rating?: number;
          total_reviews?: number;
        };
      };
      skills: {
        Row: {
          id: string;
          name: string;
          category: string;
          description: string | null;
          created_at: string;
        };
        Insert: {
          name: string;
          category: string;
          description?: string | null;
        };
        Update: {
          name?: string;
          category?: string;
          description?: string | null;
        };
      };
      user_skills: {
        Row: {
          id: string;
          user_id: string;
          skill_id: string;
          skill_type: 'offer' | 'want';
          experience_level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
          description: string | null;
          created_at: string;
        };
        Insert: {
          user_id: string;
          skill_id: string;
          skill_type: 'offer' | 'want';
          experience_level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
          description?: string | null;
        };
        Update: {
          skill_type?: 'offer' | 'want';
          experience_level?: 'beginner' | 'intermediate' | 'advanced' | 'expert';
          description?: string | null;
        };
      };
      skill_matches: {
        Row: {
          id: string;
          requester_id: string;
          provider_id: string;
          requested_skill_id: string;
          offered_skill_id: string;
          status: 'pending' | 'accepted' | 'declined' | 'completed';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          requester_id: string;
          provider_id: string;
          requested_skill_id: string;
          offered_skill_id: string;
          status?: 'pending' | 'accepted' | 'declined' | 'completed';
        };
        Update: {
          status?: 'pending' | 'accepted' | 'declined' | 'completed';
        };
      };
    };
  };
};