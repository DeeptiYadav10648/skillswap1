/*
  # SkillSwap Database Schema

  1. New Tables
    - `profiles`
      - `id` (uuid, references auth.users)
      - `username` (text, unique)
      - `full_name` (text)
      - `avatar_url` (text)
      - `bio` (text)
      - `location` (text)
      - `rating` (decimal)
      - `total_reviews` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `skills`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `category` (text)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `user_skills`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `skill_id` (uuid, references skills)
      - `skill_type` (enum: 'offer', 'want')
      - `experience_level` (enum: 'beginner', 'intermediate', 'advanced', 'expert')
      - `description` (text)
      - `created_at` (timestamp)
    
    - `skill_matches`
      - `id` (uuid, primary key)
      - `requester_id` (uuid, references profiles)
      - `provider_id` (uuid, references profiles)
      - `requested_skill_id` (uuid, references skills)
      - `offered_skill_id` (uuid, references skills)
      - `status` (enum: 'pending', 'accepted', 'declined', 'completed')
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `conversations`
      - `id` (uuid, primary key)
      - `match_id` (uuid, references skill_matches)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `messages`
      - `id` (uuid, primary key)
      - `conversation_id` (uuid, references conversations)
      - `sender_id` (uuid, references profiles)
      - `content` (text)
      - `created_at` (timestamp)
    
    - `reviews`
      - `id` (uuid, primary key)
      - `match_id` (uuid, references skill_matches)
      - `reviewer_id` (uuid, references profiles)
      - `reviewee_id` (uuid, references profiles)
      - `rating` (integer, 1-5)
      - `comment` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Add policies for public read access where appropriate
*/

-- Create custom types
CREATE TYPE skill_type AS ENUM ('offer', 'want');
CREATE TYPE experience_level AS ENUM ('beginner', 'intermediate', 'advanced', 'expert');
CREATE TYPE match_status AS ENUM ('pending', 'accepted', 'declined', 'completed');

-- Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  full_name text NOT NULL,
  avatar_url text,
  bio text,
  location text,
  rating decimal(3,2) DEFAULT 0.00,
  total_reviews integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Skills table
CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  category text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE skills ENABLE ROW LEVEL SECURITY;

-- User skills table
CREATE TABLE IF NOT EXISTS user_skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  skill_id uuid REFERENCES skills(id) ON DELETE CASCADE NOT NULL,
  skill_type skill_type NOT NULL,
  experience_level experience_level NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, skill_id, skill_type)
);

ALTER TABLE user_skills ENABLE ROW LEVEL SECURITY;

-- Skill matches table
CREATE TABLE IF NOT EXISTS skill_matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  provider_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  requested_skill_id uuid REFERENCES skills(id) ON DELETE CASCADE NOT NULL,
  offered_skill_id uuid REFERENCES skills(id) ON DELETE CASCADE NOT NULL,
  status match_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE skill_matches ENABLE ROW LEVEL SECURITY;

-- Conversations table
CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid REFERENCES skill_matches(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid REFERENCES conversations(id) ON DELETE CASCADE NOT NULL,
  sender_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid REFERENCES skill_matches(id) ON DELETE CASCADE NOT NULL,
  reviewer_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  reviewee_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  rating integer CHECK (rating >= 1 AND rating <= 5) NOT NULL,
  comment text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(match_id, reviewer_id)
);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Profiles policies
CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Skills policies
CREATE POLICY "Anyone can view skills"
  ON skills FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create skills"
  ON skills FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- User skills policies
CREATE POLICY "Users can view all user skills"
  ON user_skills FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage own skills"
  ON user_skills FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Skill matches policies
CREATE POLICY "Users can view their matches"
  ON skill_matches FOR SELECT
  TO authenticated
  USING (auth.uid() = requester_id OR auth.uid() = provider_id);

CREATE POLICY "Users can create matches"
  ON skill_matches FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = requester_id);

CREATE POLICY "Users can update their matches"
  ON skill_matches FOR UPDATE
  TO authenticated
  USING (auth.uid() = requester_id OR auth.uid() = provider_id);

-- Conversations policies
CREATE POLICY "Users can view their conversations"
  ON conversations FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM skill_matches 
      WHERE id = match_id 
      AND (requester_id = auth.uid() OR provider_id = auth.uid())
    )
  );

CREATE POLICY "Users can create conversations"
  ON conversations FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM skill_matches 
      WHERE id = match_id 
      AND (requester_id = auth.uid() OR provider_id = auth.uid())
    )
  );

-- Messages policies
CREATE POLICY "Users can view messages in their conversations"
  ON messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM conversations c
      JOIN skill_matches sm ON c.match_id = sm.id
      WHERE c.id = conversation_id 
      AND (sm.requester_id = auth.uid() OR sm.provider_id = auth.uid())
    )
  );

CREATE POLICY "Users can send messages in their conversations"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM conversations c
      JOIN skill_matches sm ON c.match_id = sm.id
      WHERE c.id = conversation_id 
      AND (sm.requester_id = auth.uid() OR sm.provider_id = auth.uid())
    )
  );

-- Reviews policies
CREATE POLICY "Users can view all reviews"
  ON reviews FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create reviews for their matches"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = reviewer_id AND
    EXISTS (
      SELECT 1 FROM skill_matches 
      WHERE id = match_id 
      AND (requester_id = auth.uid() OR provider_id = auth.uid())
      AND status = 'completed'
    )
  );

-- Insert some default skills
INSERT INTO skills (name, category, description) VALUES
  ('JavaScript', 'Programming', 'Modern JavaScript development and frameworks'),
  ('Python', 'Programming', 'Python programming and data science'),
  ('React', 'Programming', 'React.js frontend development'),
  ('Node.js', 'Programming', 'Backend JavaScript development'),
  ('UI/UX Design', 'Design', 'User interface and experience design'),
  ('Graphic Design', 'Design', 'Visual design and branding'),
  ('Digital Marketing', 'Marketing', 'Online marketing strategies and tools'),
  ('Content Writing', 'Writing', 'Blog posts, articles, and copy writing'),
  ('Photography', 'Creative', 'Digital photography and editing'),
  ('Spanish', 'Language', 'Spanish language tutoring'),
  ('French', 'Language', 'French language tutoring'),
  ('Guitar', 'Music', 'Acoustic and electric guitar lessons'),
  ('Piano', 'Music', 'Piano lessons for all levels'),
  ('Yoga', 'Fitness', 'Yoga instruction and wellness'),
  ('Cooking', 'Lifestyle', 'Culinary skills and recipe development'),
  ('Data Analysis', 'Programming', 'Data analysis with Python and R'),
  ('Machine Learning', 'Programming', 'AI and machine learning development'),
  ('Mobile Development', 'Programming', 'iOS and Android app development'),
  ('Video Editing', 'Creative', 'Video production and editing'),
  ('SEO', 'Marketing', 'Search engine optimization');

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_skill_matches_updated_at BEFORE UPDATE ON skill_matches
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_conversations_updated_at BEFORE UPDATE ON conversations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();